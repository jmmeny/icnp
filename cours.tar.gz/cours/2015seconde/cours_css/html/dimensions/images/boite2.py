import svgwrite
 

u = 80  # unité

hauteur = 2
largeur = 4

boite = svgwrite.Drawing('boiteborder.svg',size=(10*u,8*u))

boite.add(boite.style(content='text{font-size:20px;}'))

 
 

boite.add(boite.rect(insert= (0*u, 0*u), size= ((largeur+6)*u,(hauteur+6)*u), fill='rgb(100,100,255)', stroke='rgb(100,100,255)' ))
boite.add(boite.rect(insert= (1*u, 1*u), size= ((largeur+4)*u,(hauteur+4)*u), fill='pink', stroke='pink'))
boite.add(boite.rect(insert= (2*u, 2*u), size= ((largeur+2)*u,(hauteur+2)*u), fill='green', stroke='green'))
boite.add(boite.rect(insert= (3*u, 3*u), size= (largeur*u, hauteur*u), fill='lightgrey', stroke='lightgrey'))

boite.add(boite.text('margin', insert=(0.5*u, 0.5*u)))
boite.add(boite.text('border', insert=(1.5*u, 1.5*u)))
boite.add(boite.text('padding', insert=(2.5*u, 2.5*u)))
boite.add(boite.text('le contenu', insert=(3*u, 4*u)))

txthauteur = boite.text( 'height', insert=(5*u, 4*u))
boite.add(txthauteur)
txthauteur.rotate(-90, (5*u,4*u))

 

eps=0.2
boite.add(boite.line(start=(5*u,7*u), end=(5*u,1*u), stroke='black' ))
boite.add(boite.line(start=((5-eps)*u,(7-eps)*u), end=(5*u,7*u), stroke='black' ))
boite.add(boite.line(start=((5+eps)*u,(7-eps)*u), end=(5*u,7*u), stroke='black' ))
boite.add(boite.line(start=((5-eps)*u,(1+eps)*u), end=(5*u,1*u), stroke='black' ))
boite.add(boite.line(start=((5+eps)*u,(1+eps)*u), end=(5*u,1*u), stroke='black' ))


txtlargeur = boite.text( 'width', insert=(4*u, 4.5*u))
boite.add(txtlargeur)
boite.add(boite.line(start=(1*u,4.5*u), end=((5+largeur)*u,4.5*u), stroke='black' ))
boite.add(boite.line(start=((1+eps)*u,(4.5+eps)*u), end=(1*u,4.5*u), stroke='black' ))
boite.add(boite.line(start=((1+eps)*u,(4.5-eps)*u), end=(1*u,4.5*u), stroke='black' ))
boite.add(boite.line(start=((5+largeur-eps)*u,(4.5+eps)*u), end=((5+largeur)*u,4.5*u), stroke='black' ))
boite.add(boite.line(start=((5+largeur-eps)*u,(4.5-eps)*u), end=((5+largeur)*u,4.5*u), stroke='black' ))


boite.save()	 
 
	

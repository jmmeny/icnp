function setup() {
  // uncomment this line to make the canvas the full size of the window
  // createCanvas(windowWidth, windowHeight);
}

function draw() {
  // draw stuff here
  // ellipse(width/2, height/2, 50, 50);
}
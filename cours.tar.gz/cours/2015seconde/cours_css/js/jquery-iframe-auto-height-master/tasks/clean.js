module.exports = {
  dist: 'dist'
};

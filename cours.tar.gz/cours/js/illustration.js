
 

 $(function() {
 
		// Permet la coloration syntaxique du JS et du CSS dans un formulaire en HTML.
		var mixedMode = {
			name: "htmlmixed",
			scriptTypes: [{matches: /\/x-handlebars-template|\/x-mustache/i, mode: null},
						{matches: /(text|application)\/(x-)?vb(a|script)/i, mode: "vbscript"}]
			};

		var delai;
		var sourceCode = []; 
		var updatePreview = [];
		
		
		
		
		
		
		
		 
	    /* ********************************************************
	               pour code sans exécution 
	       ******************************************************** */
		var tableauCodeNonActif = 	document.getElementsByClassName("codenonactif");
		for(var i=0; i<tableauCodeNonActif.length; i += 1)
		{
			    
			     CodeMirror.fromTextArea( tableauCodeNonActif[i], {
				    lineNumbers: true,
				    mode: mixedMode,
				    matchBrackets: true,
				    readOnly: true
				 });			
		};
		
		 
		  
			
		/* ********************************************************
	               Pour les illustrations par code actif
	       ******************************************************** */
		tabCode = document.getElementsByClassName("codeactif");
		 
	    tabAffichage = document.getElementsByClassName("affichagecodeactif");
	    
	      
	    
	    for(i=0; i<tabCode.length; i++)
		{
			        sourceCode[i] = CodeMirror.fromTextArea( tabCode[i], {
				        lineNumbers: true,
				        mode: mixedMode,
				        matchBrackets: true,
				        viewportMargin: Infinity
				        }
			        );
			

			        sourceCode[i].on("change", (function(tmp) {
				        return function(){
				        clearTimeout(delai);
				        delai = setTimeout(updatePreview[tmp], 300);
				        };
			        })(i));
			
			
			

			        updatePreview[i] = (function(tmp) {
				        return function(){
					        var previewFrame = tabAffichage[tmp];
					        var preview =  previewFrame.contentDocument ||  previewFrame.contentWindow.document;
					        preview.open();
					        preview.write(sourceCode[tmp].getValue());
					        preview.close();
				        };
			        })(i);

			        setTimeout(updatePreview[i], 300);
			        
			         
        }; 
            
            
          
          
 
}); 


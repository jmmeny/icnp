See: [https://github.com/house9/jquery-iframe-auto-height#plugin-development](https://github.com/house9/jquery-iframe-auto-height#plugin-development)

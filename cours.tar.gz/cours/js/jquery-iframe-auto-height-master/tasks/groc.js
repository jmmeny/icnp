module.exports = {
  groc: {
    files: {
      src: ['src/**/*.js']
    },
    options: {
      out: 'docs/'
    }
  }
};

$(function() {

 

        $('iframe').iframeAutoHeight({
          debug: true,
          minHeight: 10,
          diagnostics: true,
	  animate: false,
	  heightOffset: 20
        });
        
        
         
      });

/* utilise jquery-iframe-auto-height-master 

voir la page /jquery-iframe-auto-height-master/README.md pour la signification des options.

Role : ajuste les iframes à leur contenu. Permet d'avoir une vision complète du rendu html dans les exercices.

 */

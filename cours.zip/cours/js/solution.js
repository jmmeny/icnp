
$(function(){

$('.solutionexercice').hide();

 

 $('.decouvrirsolution').each(
    function(index){
 
 $('.decouvrirsolution').eq(index).click(function(){
 
            $('.solutionexercice').eq(index).show();
            
            
             $('iframe').iframeAutoHeight({
              debug: true,
              minHeight: 10,
              diagnostics: true,
	          animate: false,
	          heightOffset: 20
        });
            
            
                       
        });

});


$('.cachersolution').each(
function(index){

$('.cachersolution').eq(index).click(function(){
 
            $('.solutionexercice').eq(index).hide();
     
              });

});



});
